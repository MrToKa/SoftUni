﻿namespace P02_FootballBetting
{
    internal class StartUp
    {
        static void Main(string[] args)
        {

        }
    }
}
