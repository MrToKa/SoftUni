﻿namespace P02_FootballBetting.Data.Models
{
    public enum Prediction
    {
        HomeWin,
        AwayWin,
        Draw
    }

}